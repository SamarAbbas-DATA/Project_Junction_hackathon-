"""
Turn the raw ARMD download (~1.1 GB, '../new model/') into one compact training file:
    ../data_real/isolates.csv.gz   - one row per isolate (culture x organism), features already built

Run once:  python prepare_data.py        (~2-4 min, needs pandas)

Cleaning decisions (all printed when run):
  * organism names are normalised (e.g. 'STAPH AUREUS {MRSA}' -> 'Staphylococcus aureus' + flag mrsa,
    'ZZZENTEROBACTER AEROGENES' -> 'Klebsiella aerogenes'); rare organisms -> 'Other'; mycobacteria dropped
  * Susceptible -> S, Resistant/Intermediate -> R ("non-susceptible", the usual convention);
    Inconclusive / Synergism / Null results dropped
  * duplicate results for the same culture+organism+antibiotic -> worst case (R wins)
  * history only uses events >= 1 day BEFORE the culture (no leakage of the culture's own result)
"""
import json
import re
import sys
import time
from collections import defaultdict
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from amr_predict import context_features, history_features, normalize_drug  # noqa: E402

RAW = Path(__file__).parent.parent / "new model"
OUT = Path(__file__).parent.parent / "data_real"
MIN_ISOLATES = 400        # organisms with fewer isolates become 'Other'
TOP_DRUGS = 30            # individual drug features for the 30 most common antibiotics; rest only by class

BASE_MAP = {
    "ESCHERICHIA COLI": "Escherichia coli",
    "KLEBSIELLA PNEUMONIAE": "Klebsiella pneumoniae",
    "KLEBSIELLA OXYTOCA": "Klebsiella oxytoca",
    "KLEBSIELLA AEROGENES": "Klebsiella aerogenes",
    "ZZZENTEROBACTER AEROGENES": "Klebsiella aerogenes",
    "ENTEROCOCCUS SPECIES": "Enterococcus (faecalis/spp.)",
    "ENTEROCOCCUS FAECALIS": "Enterococcus (faecalis/spp.)",
    "ENTEROCOCCUS FAECIUM": "Enterococcus faecium",
    "STAPHYLOCOCCUS AUREUS": "Staphylococcus aureus",
    "STAPH AUREUS": "Staphylococcus aureus",
    "STAPH AUREUS(COLONY VARIANT - SMALL COLONY OR OTHER MORPHOTYPE)": "Staphylococcus aureus",
    "PSEUDOMONAS AERUGINOSA": "Pseudomonas aeruginosa",
    "PROTEUS MIRABILIS": "Proteus mirabilis",
    "STREPTOCOCCUS AGALACTIAE (GROUP B)": "Streptococcus agalactiae (group B)",
    "STREPTOCOCCUS AGALACTIAE {GROUP B}": "Streptococcus agalactiae (group B)",
    "COAG NEGATIVE STAPHYLOCOCCUS": "Coagulase-negative staphylococci",
    "STAPHYLOCOCCUS SPECIES - COAG NEGATIVE, NOT STAPH SAPROPHYTICUS": "Coagulase-negative staphylococci",
    "ENTEROBACTER CLOACAE COMPLEX": "Enterobacter cloacae complex",
    "ENTEROBACTER CLOACAE": "Enterobacter cloacae complex",
    "STENOTROPHOMONAS MALTOPHILIA": "Stenotrophomonas maltophilia",
    "CITROBACTER KOSERI": "Citrobacter koseri",
    "CITROBACTER FREUNDII COMPLEX": "Citrobacter freundii complex",
    "CITROBACTER FREUNDII": "Citrobacter freundii complex",
    "SERRATIA MARCESCENS": "Serratia marcescens",
    "STREPTOCOCCUS PNEUMONIAE": "Streptococcus pneumoniae",
    "MORGANELLA MORGANII": "Morganella morganii",
    "ACHROMOBACTER XYLOSOXIDANS": "Achromobacter xylosoxidans",
}
FLAG_PATTERNS = [  # (regex on raw name, flag)
    (r"\{?\bMRSA\b\}?", "mrsa"),
    (r"\(?\bCARBAPENEM RESISTANT\b\)?", "cre"),
    (r"-?\s*\bVANCO(MYCIN)? RESISTANT\b|\bVRE\b", "vre"),
    (r"\(?\bESBL\b\)?", "esbl"),
    (r"\(NON-MUCOID CF\)", "cf"),
    (r"^MUCOID\s+", "mucoid"),
]
RESULT_MAP = {"Susceptible": "S", "Resistant": "R", "Intermediate": "R"}


def canon_organism(raw):
    name, flags = str(raw).strip(), set()
    for pat, flag in FLAG_PATTERNS:
        if re.search(pat, name):
            flags.add(flag)
            name = re.sub(pat, "", name).strip(" -")
    name = re.sub(r"\s+", " ", name)
    return BASE_MAP.get(name), flags


def main():
    t0 = time.time()
    OUT.mkdir(exist_ok=True)
    log = {}

    # ---------------- cohort
    c = pd.read_csv(RAW / "microbiology_cultures_cohort.csv", dtype=str)
    log["cohort rows"] = len(c)
    c["time"] = pd.to_datetime(c.order_time_jittered_utc, utc=True)
    pos = c[c.organism != "Null"].copy()
    log["culture orders total / positive"] = f"{c.order_proc_id_coded.nunique()} / {pos.order_proc_id_coded.nunique()}"

    names = pos.organism.unique()
    canon = {n: canon_organism(n) for n in names}
    flagged = {n: sorted(f) for n, (o, f) in canon.items() if f}
    print("organism names carrying flags:", json.dumps(flagged, indent=1))
    pos["org"] = pos.organism.map(lambda n: canon[n][0])
    pos["flags"] = pos.organism.map(lambda n: canon[n][1])
    pos = pos[~pos.organism.str.contains("MYCOBACTERIUM")]  # TB-type organisms: different testing entirely
    counts = pos.drop_duplicates(["order_proc_id_coded", "org"]).org.value_counts()
    keep = set(counts[counts >= MIN_ISOLATES].index)
    pos["org"] = pos.org.where(pos.org.isin(keep), "Other")
    print("modelled organisms:", counts[counts.index.isin(keep)].to_dict())

    # ---------------- AST results
    ast = pos[pos.antibiotic != "Null"].copy()
    ast["res"] = ast.susceptibility.map(RESULT_MAP)
    log["AST rows dropped (Inconclusive/Synergism/Null)"] = int(ast.res.isna().sum())
    ast = ast[ast.res.notna() & (ast.org != "Other")]
    before = len(ast)
    ast = (ast.assign(isR=ast.res == "R")
              .groupby(["order_proc_id_coded", "org", "antibiotic"], as_index=False).isR.max())
    log["AST rows merged as duplicates (worst case kept)"] = before - len(ast)
    ast["res"] = ast.isR.map({True: "R", False: "S"})
    results = defaultdict(dict)
    for o, org, abx, r in ast[["order_proc_id_coded", "org", "antibiotic", "res"]].itertuples(index=False):
        results[(o, org)][abx] = r

    iso = (pos.groupby(["order_proc_id_coded", "org"])
              .agg(anon_id=("anon_id", "first"), time=("time", "first"),
                   specimen=("culture_description", "first"), mode=("ordering_mode", "first"),
                   flags=("flags", lambda s: sorted(set().union(*s))))
              .reset_index())
    iso["results"] = [results.get((o, g), {}) for o, g in zip(iso.order_proc_id_coded, iso.org)]
    log["isolates"] = len(iso)

    # ---------------- context: demographics + ward
    dem = pd.read_csv(RAW / "microbiology_cultures_demographics.csv", dtype=str)[["order_proc_id_coded", "age", "gender"]]
    ward = pd.read_csv(RAW / "microbiology_cultures_ward_info.csv", dtype=str)
    ward = ward.drop_duplicates("order_proc_id_coded")[["order_proc_id_coded", "hosp_ward_IP", "hosp_ward_OP", "hosp_ward_ER", "hosp_ward_ICU"]]
    iso = iso.merge(dem.drop_duplicates("order_proc_id_coded"), on="order_proc_id_coded", how="left") \
             .merge(ward, on="order_proc_id_coded", how="left")

    # ---------------- history 1: prior resistance
    needed = set(iso.order_proc_id_coded)
    hist = defaultdict(lambda: {"prior_results": [], "prior_antibiotics": [], "prior_organisms": [], "nursing_home": False})
    r = pd.read_csv(RAW / "microbiology_cultures_microbial_resistance.csv", dtype={"order_proc_id_coded": str})
    r = r[r.order_proc_id_coded.isin(needed)]
    rcanon = {n: (canon_organism(n)[0] or "Other") for n in r.organism.unique()}
    for o, org, abx, d in r[["order_proc_id_coded", "organism", "antibiotic", "resistant_time_to_culturetime"]].itertuples(index=False):
        hist[o]["prior_results"].append({"antibiotic": abx, "organism": rcanon[org], "result": "R", "days_ago": d})
    log["prior-resistance records used (ARMD file)"] = len(r)

    # ---------------- history 1b: prior R *and* S results from the patient's own earlier cultures in the cohort.
    # The ARMD resistance file only covers some antibiotics (e.g. not TMP/SMX, pip-tazo, oxacillin), so this fills
    # the gap. A prior culture only counts if taken >= 3 days earlier, i.e. its result would really be available.
    ast_t = ast.merge(iso[["order_proc_id_coded", "org", "anon_id", "time"]], on=["order_proc_id_coded", "org"])
    cur = iso[["anon_id", "order_proc_id_coded", "time"]].drop_duplicates("order_proc_id_coded")
    mm = cur.merge(ast_t[["anon_id", "org", "antibiotic", "res", "time"]], on="anon_id", suffixes=("", "_prev"))
    mm["days"] = (mm.time - mm.time_prev).dt.total_seconds() / 86400
    mm = mm[mm.days >= 3]
    for o, org, abx, res, d in mm[["order_proc_id_coded", "org", "antibiotic", "res", "days"]].itertuples(index=False):
        hist[o]["prior_results"].append({"antibiotic": abx, "organism": org, "result": res, "days_ago": d})
    log["prior results from earlier cultures (R+S)"] = len(mm)

    # ---------------- history 2: prior antibiotic exposure (last 365 days)
    e = pd.read_csv(RAW / "microbiology_cultures_antibiotic_class_exposure.csv",
                    usecols=["order_proc_id_coded", "medication_name", "antibiotic_class", "time_to_culturetime"],
                    dtype={"order_proc_id_coded": str})
    e = e[(e.time_to_culturetime <= 365) & e.order_proc_id_coded.isin(needed)]
    e["drug"] = e.medication_name.map({n: normalize_drug(n) for n in e.medication_name.unique()})
    top_drugs = set(e.drop_duplicates(["order_proc_id_coded", "drug"]).drug.value_counts().head(TOP_DRUGS).index)
    print("drug-level exposure features for:", sorted(top_drugs))
    e = e.drop_duplicates(["order_proc_id_coded", "drug", "antibiotic_class", "time_to_culturetime"])
    for o, drug, cls, d in e[["order_proc_id_coded", "drug", "antibiotic_class", "time_to_culturetime"]].itertuples(index=False):
        hist[o]["prior_antibiotics"].append({"drug": drug if drug in top_drugs else None, "antibiotic_class": cls, "days_ago": d})
    log["prior-antibiotic records used (<=365d)"] = len(e)

    # ---------------- history 3: nursing home
    nh = pd.read_csv(RAW / "microbiology_cultures_nursing_home_visits.csv", dtype={"order_proc_id_coded": str})
    for o in set(nh.order_proc_id_coded) & needed:
        hist[o]["nursing_home"] = True

    # ---------------- history 4: prior organisms (from earlier positive cultures of the same patient)
    porg = pos[pos.org != "Other"].drop_duplicates(["order_proc_id_coded", "org"])[["anon_id", "order_proc_id_coded", "time", "org"]]
    orders = iso[["anon_id", "order_proc_id_coded", "time"]].drop_duplicates("order_proc_id_coded")
    m = orders.merge(porg, on="anon_id", suffixes=("", "_prev"))
    m["days"] = (m.time - m.time_prev).dt.total_seconds() / 86400
    m = m[m.days >= 1]
    for o, org, d in m[["order_proc_id_coded", "org", "days"]].itertuples(index=False):
        hist[o]["prior_organisms"].append({"organism": org, "days_ago": d})
    log["prior-organism links"] = len(m)

    # ---------------- build feature tokens with the SAME functions inference uses
    rows = []
    for x in iso.itertuples(index=False):
        wf = [w for w, col in (("IP", x.hosp_ward_IP), ("OP", x.hosp_ward_OP), ("ER", x.hosp_ward_ER), ("ICU", x.hosp_ward_ICU)) if col == "1"]
        mode = None if x.mode in (None, "Null") or pd.isna(x.mode) else x.mode
        ctx = context_features(x.specimen, age=x.age, gender=x.gender, ward_flags=wf, ordering_mode=mode)
        h = hist.get(x.order_proc_id_coded)
        hf = history_features(h, None if x.org == "Other" else x.org) if h else []
        rows.append((f"{x.order_proc_id_coded}#{x.org}", x.anon_id, x.time.strftime("%Y-%m-%d"), x.specimen.lower(),
                     x.org, "|".join(x.flags), "|".join(ctx), "|".join(hf), json.dumps(x.results, separators=(",", ":"))))
    out = pd.DataFrame(rows, columns=["isolate_id", "patient_id", "date", "specimen", "organism", "flags",
                                      "context", "history", "results"])
    out = out.sort_values("date").reset_index(drop=True)
    path = OUT / "isolates.csv.gz"
    out.to_csv(path, index=False, compression="gzip")

    log["isolates written"] = len(out)
    log["isolates with any history feature"] = int((out.history != "").sum())
    log["output"] = f"{path} ({path.stat().st_size / 1e6:.1f} MB)"
    log["seconds"] = round(time.time() - t0)
    for k, v in log.items():
        print(f"{k:50s} {v}")


if __name__ == "__main__":
    main()
